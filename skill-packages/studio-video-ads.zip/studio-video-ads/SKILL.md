---
name: studio-video-ads
description: Dựng video quảng cáo sản phẩm bằng Remotion từ brief, ảnh sản phẩm, footage và voice. Dùng khi cần kịch bản, phân cảnh, motion sản phẩm, chữ tiếng Việt, phối âm, phụ đề, kiểm tra và xuất video quảng cáo.
---

# Studio Video Ads

Create and refine product adverts with a complete, reviewable production workflow. Vietnamese is the default response and on-screen language when the user speaks Vietnamese. This skill contains the official Remotion reference bundle in `references/remotion/`; it does not install the Remotion runtime or grant access to external services.

## 1. Establish the actual task

Read the user's brief and existing project instructions. Preserve existing edits, original media, existing exports and credentials. Work in the current checkout; do not make a worktree unless requested. Infer reasonable creative defaults from the supplied reference and continue useful work. Do not request repeated approvals for steps already authorized. Only ask for missing details that prevent progress.

Choose the deliverable the user asked for: analysis, script, storyboard, editable composition, render, or revision. Do not silently replace one with another. Prefer the current working video engine for an existing edit; migrating HyperFrames/FFmpeg to Remotion requires a task reason or user request.

## 2. Inspect inputs before describing them

Run `python3 scripts/inspect_media.py <paths...>` to get ffprobe metadata. View timestamped samples and scene boundaries from supplied video. Record source paths and selected time ranges in an asset manifest. Keep originals untouched. Place generated work under `<project>/edit/` or the repository's established output directory.

Separate observed picture, visible on-screen text, measured audio, and inferred narrative. Do not describe a voice, music or sound effect as heard when only metadata/waveforms were inspected. Do not invent ASR transcripts or word timings. When ASR is unavailable, use verified supplied scripts and measured pauses for provisional section timing; state that captions are not word-verified.

Use existing user assets first. For online assets, record the source URL and verified usage terms. Report blocked destinations rather than inventing downloads or licenses. Preserve source branding; do not imply speakers endorse the advertised product or show unrelated footage as proven before/after results.

## 3. Script and plan

Use `references/production-checklist.md`. Deliver a storyboard with output time, source file/time range, voice, on-screen text, motion and sound cues. Prefer problem → product → supported benefits → application/context → CTA when suitable. Scale the structure to the material instead of forcing every advert into one template.

Product claims come from user-provided labels/documents and must not be strengthened without evidence. Do not invent certifications, treatment outcomes, prices, dose rates, endorsements or guarantees. User-requested free consultation is a CTA, not a promise of product efficacy.

For this project's existing VNBio work, read `references/project-preferences.md`; those preferences are not defaults for unrelated clients.

## 4. Author with Remotion when appropriate

Read `references/remotion/SKILL.md` and then the applicable linked guides before coding. New video: remotion-create/REFERENCE.md; markup: remotion-markup/REFERENCE.md; speech captions: remotion-captions/REFERENCE.md; exports: remotion-render/REFERENCE.md. Preserve the relative structure of the bundled references.

Check the actual installed Remotion version before using an API from the reference snapshot. Add version-compatible packages using the documented commands. Drive animation from `useCurrentFrame()` and `useVideoConfig()` using interpolate/spring/easing, not a wall clock or CSS animation. Keep deterministic, seekable behavior. Reference public assets with staticFile. Use compatible Remotion media components and premount where supported.

Create an explicit visual identity before authoring: palette, Vietnamese-capable fonts, type scale, safe areas and motion style. Make hero frame layouts readable before animation. Keep product labels and silhouettes intact; background removal or generative edits must be checked against original packaging. Do not redraw tiny label text through image/video generation.

Use editable scene components, separate source-authored clips where users need individual Studio edits, and supported timing props. Apply the upstream guides on interactivity, connected compositions, measuring text, transitions and effects as relevant. Check preview when available. Do not advertise localhost links as accessible on the user's machine without verified forwarding.

## 5. Typography and motion

For a 1080x1920 social advert, start with 70–110px display text, 44–60px callouts, 40–48px captions; fit actual Vietnamese copy and check on a phone-size image. These are starting points, not mandates. Keep key content clear of platform UI; adjust to target platform. Give a claim enough hold time to read.

One principal message per beat. Keep hierarchy between brand, product, claim, caption and CTA. Avoid covering product labels or source text. Reveal benefits with the corresponding narrated thought. Use restrained, consistent transitions and transform/opacity motion; vary entrances when useful. Keep the CTA and contact information stable long enough to act.

## 6. Audio

Use the user's supplied voice unless another voice is requested. Preserve an original copy. When speed/pause changes are authorized, trim silence without removing speech, make pitch-preserving speed changes, and record the changes. Keep product names and phone numbers intelligible; do not claim subjective listening checks if unavailable.

Music should support speech. Use licensed/authorized media or clearly identified original synthesis. Tie SFX to visible events, avoid one whoosh per cut, and duck the music beneath the voice. Fade discontinuous audio edges. Measure final encoded loudness and true peak, not just stems. An initial social target is -14 to -16 LUFS integrated and <=-1 dBTP; adjust for platform and content rather than imposing it universally.

Do not require ElevenLabs, Vbee or another paid service just to render supplied voice. Inspect existing configuration by binding names/presence only before requesting credentials. Never request secret values in chat or write them to source files.

## 7. Verify and deliver

Run relevant type/build checks for changed code, representative frame renders, and full decode of the final video. Check scene seams and representative hero frames, captions, brand, package crop, phone number, duration, frame rate, resolution, audio channels and final loudness. Distinguish a draft from a final approved export. Report remaining defects and unavailable checks plainly.

If the task explicitly requests an MP4, render it; otherwise follow the requested preview/editable deliverable. Keep high-resolution master separate from lightweight previews. Do not present a reduced preview as the HD master. Verify the delivery route and downloaded bytes when possible. The current Codex file preview may fail for large assets; see project delivery history in `references/project-preferences.md`.

Publishing to public GitHub or another external service requires authorization for that content and destination. Once authorized, publish only the selected files, preserve unrelated changes and verify the resulting download. Never push secrets or extra project files under authorization to upload one video.

Finish with the artifact link, concrete changes, validation and material limits. Do not claim permanent memory, live browser control, working credentials, successful exports or accessible previews without evidence.
