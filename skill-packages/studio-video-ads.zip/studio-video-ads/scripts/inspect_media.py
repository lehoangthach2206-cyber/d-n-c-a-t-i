"""Inspect media without changing files or printing environment credentials."""
import argparse
import json
import shutil
import subprocess
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('files', nargs='+', type=Path)
    args = parser.parse_args()
    if not shutil.which('ffprobe'):
        parser.error('ffprobe is required; install FFmpeg first')
    failed = False
    for path in args.files:
        if not path.is_file():
            print(json.dumps({'path': str(path), 'error': 'File not found'}, ensure_ascii=False))
            failed = True
            continue
        result = subprocess.run([
            'ffprobe', '-v', 'error', '-show_entries',
            'format=duration,size:stream=codec_type,codec_name,width,height,r_frame_rate,sample_rate,channels',
            '-of', 'json', str(path.resolve())
        ], capture_output=True, text=True)
        if result.returncode:
            print(json.dumps({'path': str(path), 'error': 'ffprobe failed'}, ensure_ascii=False))
            failed = True
        else:
            print(json.dumps({'path': str(path), **json.loads(result.stdout)}, ensure_ascii=False))
    raise SystemExit(1 if failed else 0)


if __name__ == '__main__':
    main()
