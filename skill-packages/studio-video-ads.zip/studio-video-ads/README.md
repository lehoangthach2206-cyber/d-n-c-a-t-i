# Studio Video Ads — Codex skill pack

Invoke with `$studio-video-ads` and your brief/assets. Example: “Dùng $studio-video-ads dựng quảng cáo dọc 45giây từ footage và voice này, không ghi giá.”

This pack includes SKILL.md, agents/openai.yaml, production guidance, an ffprobe helper, and the complete official Remotion aggregate reference snapshot. Official source provenance and checksums are in references/remotion/UPSTREAM.json. References have been preserved unchanged.

## Installation

Extract the studio-video-ads folder into your Codex skills directory, normally ~/.codex/skills/ or $CODEX_HOME/skills/. Keep SKILL.md and the whole references and scripts folders together. For a project-local installation, use .agents/skills/studio-video-ads. If Codex does not discover it in an existing session, open a new session or explicitly read its SKILL.md. Automatic discovery has not been verified until the client actually lists/invokes it.

No API keys, models or Remotion dependencies are included. FFmpeg is required for scripts/inspect_media.py; Node.js and version-compatible Remotion packages are required only when creating/rendering a Remotion project. Existing working videos are not migrated by this skill.

This package was assembled for the user's personal studio. Existing VNBio preferences are documented separately; do not apply them to unrelated jobs.
