# Existing project: VNBio / BioFu + FuBa

These preferences come from this conversation and apply to this advert, not every future job.

- Vietnamese agricultural product advertising; vertical9:16; real footage combined with readable product motion graphics.
- Products: BioFu250ml and FuBa500ml. Keep real packaging and brand text. Consult the user's complete supplied product information before adding any new claim.
- Do not put prices on screen or in voice.
- CTA: receive free consultation. Approved contact: `0888 05 07 58`.
- User supplied voice and authorized speed/pause changes. Preserve the original. Existing draft uses1.02speed and shortens6long pauses; full captions were not transcribed/word-verified.
- Source clips include Hoàng Long Garden/Cayantrai.vn and THDT branding. Their presence does not imply endorsement or verified treatment outcome; usage rights for advertising have not been established.
- Original draft master: `/workspace/shared/biofu-sources/edit/BIOFU-FUBA-preview.mp4`,1080x1920,30fps,48.8seconds. Use existing files only after verifying they still exist.
- Lightweight480p preview was downloadable but blurry. Large embedded HTML and direct workspace MP4 links failed in the user's Codex UI; do not repeatedly suggest the same failed route as proven.
- User explicitly authorized uploading that specific MP4 to the public repository lehoangthach2206-cyber/d-n-c-a-t-i. It was uploaded at video-export/BIOFU-FUBA-1080p.mp4 and remote bytes matched the local master. This does not authorize publishing new files/versions automatically.
- Existing studio implementation and HyperFrames/FFmpeg source should be preserved. Skill installation alone does not rebuild or migrate the advert.
