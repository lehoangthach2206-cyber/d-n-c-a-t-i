# Production checklist

## Brief
- Product and source documents; goal, audience, language and platform.
- Duration, aspect ratio, supplied assets, voice and visual reference.
- Must-show claims, CTA, contact details, forbidden content (such as prices).
- Reuse established answers; make reasonable assumptions explicit.

## Storyboard format

| Output time | Source + in/out | Visual | Voice | Text | Motion | Audio cue |
|---|---|---|---|---|---|---|
| 0–3 s | filename, verified source range | Hook image | Supplied/approved words | One short headline | Readable entrance | One timed accent |

## Before rendering
- Actual fonts include Vietnamese diacritics; text is not clipped or covering labels.
- Animation is frame-driven and repeatable, timings fit the actual voice.
- Source rights/status and branding are recorded; no fabricated endorsement/result.
- Preview and master have distinct filenames and stated resolutions.

## After rendering
- Verify metadata and full decode on the actual output.
- Inspect every scene boundary and representative start/middle/end frames.
- Check product labels, phone number, claims, caption correctness and safe areas.
- Measure final loudness and true peak; clearly distinguish hearing from measurement.
- Save source/EDL/timing changes and production notes so revisions are reproducible.
- Deliver the requested artifact with a route appropriate to this environment.
