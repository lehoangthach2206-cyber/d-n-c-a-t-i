@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CAI_DU_AN_WINDOWS.ps1"
pause
