Add-Type -AssemblyName System.Windows.Forms
$ErrorActionPreference = 'Stop'
try {
  if (Get-Process -Name CapCut -ErrorAction SilentlyContinue) { throw 'Please close CapCut first, then run this installer again.' }
  $pick = New-Object System.Windows.Forms.FolderBrowserDialog
  $pick.Description = 'Choose the CapCut drafts folder (Settings > Draft location). Your existing projects will not be overwritten.'
  $defaultPath = Join-Path $env:LOCALAPPDATA 'CapCut\User Data\Projects\com.lveditor.draft'
  if (Test-Path $defaultPath) { $pick.SelectedPath = $defaultPath }
  if ($pick.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit }
  $draftRoot = $pick.SelectedPath
  $source = Join-Path $PSScriptRoot 'VBBS_Polish_80s'
  $name = 'VBBS_Polish_80s'
  $target = Join-Path $draftRoot $name
  if (Test-Path $target) { $name = $name + '_' + (Get-Date -Format 'yyyyMMdd_HHmmss'); $target = Join-Path $draftRoot $name }
  Copy-Item -LiteralPath $source -Destination $target -Recurse
  $portableTarget = $target.Replace('\','/')
  $portableRoot = $draftRoot.Replace('\','/')
  $utf8 = New-Object System.Text.UTF8Encoding($false)
  foreach ($file in @('draft_content.json','draft_meta_info.json')) {
    $path = Join-Path $target $file
    $raw = [System.IO.File]::ReadAllText($path)
    $raw = $raw.Replace('@@PROJECT_DIR@@',$portableTarget).Replace('@@DRAFT_ROOT@@',$portableRoot)
    [System.IO.File]::WriteAllText($path,$raw,$utf8)
  }
  $metaPath = Join-Path $target 'draft_meta_info.json'
  $meta = [System.IO.File]::ReadAllText($metaPath) | ConvertFrom-Json
  $meta.draft_name = $name
  $meta.draft_cover = $portableTarget + '/draft_cover.jpg'
  $meta.draft_fold_path = $portableTarget
  $meta.draft_root_path = $portableRoot
  [System.IO.File]::WriteAllText($metaPath,($meta | ConvertTo-Json -Depth 100),$utf8)
  [System.Windows.Forms.MessageBox]::Show(('Installed: ' + $target + "`nOpen CapCut and find " + $name + ".`nIf fonts differ, install the two fonts in the media folder and reopen CapCut."),'VBBS project ready') | Out-Null
} catch {
  [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'VBBS installation') | Out-Null
  exit 1
}
